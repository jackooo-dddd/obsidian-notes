## 1. Rocq 源码
`Corelib/Init/Peano.v:181`：

```coq
Definition lt (n m:nat) := S n <= m.
```

`<=` 是 `le` 的记号（`Peano.v:169-174`），所以它的意思是 `lt n m := le (S n) m`，也就是"n < m 定义为 n+1 ≤ m"。

Rocq kernel 里的这条声明是：

```coq
lt : nat -> nat -> Prop
lt := fun (n m : nat) => le (S n) m
```

## 2. 源 AST（source.ndjson）
**type**（JSON 原文）：

```json
{"k":"prod","n":{"n":"n"},"ty":{"k":"ind","ind":{"mind":"Corelib.Init.Datatypes.nat","i":0}},
 "b":{"k":"prod","n":{"n":"m"},"ty":{"k":"ind","ind":{"mind":"Corelib.Init.Datatypes.nat","i":0}},
      "b":{"k":"sort","s":{"k":"prop"}}}}
```

简写：

```
prod(n, ind nat, prod(m, ind nat, sort prop))
```

**body**（JSON 原文）：

```json
{"k":"lam","n":{"n":"n"},"ty":{"k":"ind","ind":{"mind":"…nat"}},
 "b":{"k":"lam","n":{"n":"m"},"ty":{"k":"ind","ind":{"mind":"…nat"}},
      "b":{"k":"app","f":{"k":"ind","ind":{"mind":"Corelib.Init.Peano.le","i":0}},
           "args":[{"k":"app","f":{"k":"construct","ind":{"mind":"…nat"},"c":1},
                    "args":[{"k":"rel","i":1}]},
                   {"k":"rel","i":0}]}}}
```

简写：

```
lam(n, ind nat, lam(m, ind nat, app(ind le, [app(construct nat 1, [rel 1]), rel 0])))
```

其中 `construct nat 1` 是 nat 的第 1 号构造子，也就是 `S`（第 0 号是 `O`）。
## 3. 目标（Lean）
**Lean 声明**：

```lean
def Rocq.Corelib.Init.Peano.lt :
    Rocq.Corelib.Init.Datatypes.nat → Rocq.Corelib.Init.Datatypes.nat → Prop :=
  fun n m => Rocq.Corelib.Init.Peano.le (Rocq.Corelib.Init.Datatypes.nat.S n) m
```

**target_type**（Lean `Expr`）：

```
forallE n (const Rocq.…nat [])
  (forallE m (const Rocq.…nat [])
    (sort 0))
```

**target_value**（Lean `Expr`）：

```
lam n (const Rocq.…nat [])
  (lam m (const Rocq.…nat [])
    (app (app (const Rocq.…Peano.le [])
              (app (const Rocq.…nat.S []) (bvar 1)))
         (bvar 0)))
```

注意 Lean 的 `app` 是二元的：源里的 `app(le, [S n, m])` 写成了 `app(app(le, S n), m)`。
## 4. 两棵树并排
**type 树**

```
源树 S                                   目标树 T

prod n                 ── 节点 T02 ──►   forall n
├─ ind nat             ── 叶子 T03 ──►   ├─ const Rocq.…nat
└─ prod m              ── 节点 T02 ──►   └─ forall m
   ├─ ind nat          ── 叶子 T03 ──►      ├─ const Rocq.…nat
   └─ sort prop        ── 叶子 U02 ──►      └─ sort 0
```

**body 树**

```
源树 S                                   目标树 T

lam n                  ── 节点 T02 ──►   lam n
├─ ind nat             ── 叶子 T03 ──►   ├─ const Rocq.…nat
└─ lam m               ── 节点 T02 ──►   └─ lam m
   ├─ ind nat          ── 叶子 T03 ──►      ├─ const Rocq.…nat
   └─ app              ── 节点 T02 ──►      └─ app
      ├─ ind le        ── 叶子 T03 ──►         ├─ const Rocq.…Peano.le
      ├─ app           ── 节点 T02 ──►         ├─ app
      │  ├─ construct nat 1 (S) ─ T03 ►        │  ├─ const Rocq.…nat.S
      │  └─ rel 1 (n)  ── 叶子 T01 ──►         │  └─ bvar 1 (n)
      └─ rel 0 (m)     ── 叶子 T01 ──►         └─ bvar 0 (m)
```

## 5. 翻译过程：逐个节点
翻译器对每棵树从根往下递归。下表"上下文"一列，最内层的变量写在右边。

**type 树**

|步|源节点|上下文|规则|结果|
|---|---|---|---|---|
|1|`prod(n, _, _)`|`[]`|T02：prod → forall；进入 body 时上下文加上 n|`forall n, _, _`|
|2|`ind nat`|`[]`|T03：查注册表|`const Rocq.…nat`|
|3|`prod(m, _, _)`|`[n]`|T02；进入 body 时加上 m|`forall m, _, _`|
|4|`ind nat`|`[n]`|T03|`const Rocq.…nat`|
|5|`sort prop`|`[n, m]`|U02：Prop → Sort 0|`sort 0`|

**body 树**

|步|源节点|上下文|规则|结果|
|---|---|---|---|---|
|1|`lam(n, _, _)`|`[]`|T02：lam → lam；进入 body 时加上 n|`lam n, _, _`|
|2|`ind nat`|`[]`|T03|`const Rocq.…nat`|
|3|`lam(m, _, _)`|`[n]`|T02；进入 body 时加上 m|`lam m, _, _`|
|4|`ind nat`|`[n]`|T03|`const Rocq.…nat`|
|5|`app(f, [a₁, a₂])`|`[n, m]`|T02：拆成 `app(app(f, a₁), a₂)`|`app(app(_, _), _)`|
|6|`ind le`|`[n, m]`|T03|`const Rocq.…Peano.le`|
|7|`app(g, [b])`|`[n, m]`|T02|`app(_, _)`|
|8|`construct nat 1`|`[n, m]`|T03：nat 的第 1 号构造子|`const Rocq.…nat.S`|
|9|`rel 1`|`[n, m]`|T01：编号 1 从右数第 2 个，是 n|`bvar 1`|
|10|`rel 0`|`[n, m]`|T01：编号 0 是最右边的 m|`bvar 0`|

整个过程**只用到 4 条规则**：T01、T02、T03、U02。没有模板，没有被删掉或多出来的节点。
## 6. 为什么两边对应
### (a) 结构相同（T1）
形状、位置、变量编号都相同，只有叶子按字典换了名字：

|源叶子|目标叶子|依据|
|---|---|---|
|`ind nat`|`Rocq.…nat`|第 1 条声明（导出顺序中排第 1）|
|`ind le`|`Rocq.…Peano.le`|第 18 条声明|
|`construct nat 1`|`Rocq.…nat.S`|nat 的第 1 号构造子，随 nat 一起生成|
|`sort prop`|`sort 0`|sort 映射 I|
|`rel 1`、`rel 0`|`bvar 1`、`bvar 0`|两边上下文都是 `[n, m]`|

`lt` 排第 20 条，它引用的 nat（第 1 条）和 le（第 18 条）都在它前面，符合 T4。

**audit 结果**：`audit.json` 中这一条是 `{"source": "Corelib.Init.Peano.lt", "status": "TRANSLATED_AND_CHECKED", "verdict": "MATCH"}`。
### (b) 类型正确（T2）
两边的类型检查**一步一步对得上**，用的是同一套规则：

|Rocq|Lean|
|---|---|
|`S : nat → nat`，`n : nat` ⊢ `S n : nat`|`Rocq.nat.S : Rocq.nat → Rocq.nat`，`n : Rocq.nat` ⊢ `Rocq.nat.S n : Rocq.nat`|
|`le : nat → nat → Prop` ⊢ `le (S n) : nat → Prop`|`Rocq.le : Rocq.nat → Rocq.nat → Prop` ⊢ `Rocq.le (S n) : Rocq.nat → Prop`|
|`m : nat` ⊢ `le (S n) m : Prop`|`m : Rocq.nat` ⊢ `Rocq.le (S n) m : Prop`|
|加上 `fun m`：`nat → Prop`|加上 `fun m`：`Rocq.nat → Prop`|
|加上 `fun n`：`nat → nat → Prop`，**等于声明的 type** |加上 `fun n`：`Rocq.nat → Rocq.nat → Prop`，**等于翻译后的 type** |

最后一行就是 kernel 做的检查：⟦body⟧ : ⟦type⟧。kernel 接受了，状态是 `TRANSLATED_AND_CHECKED`。

注意：翻译时 type 树和 body 树是**分别**按规则算的，翻译器没有拿它们互相对照。它们能对上，是因为两边的类型规则相同，而规则在每个节点都保持了类型。
### (c) 行为相同（T3）
`lt` 是透明定义，两边都可以展开：

```
Rocq:  lt 2 5   ⇝δ  (fun n m => le (S n) m) 2 5   ⇝β  le 3 5
Lean:  Rocq.lt 2 5  ⇝δ  (fun n m => Rocq.le (S n) m) 2 5  ⇝β  Rocq.le 3 5
```

每一步都是对面那一步的翻译。所以 Rocq 里任何"靠展开 lt 才成立"的推理（例如证明 `lt n m` 时先 `unfold lt`），在 Lean 里都同样成立。
### (d) 意思
两边说的都是"**n < m 的意思是 n+1 ≤ m**"：
- `le` 和 `nat` 是之前已经确认的叶子；
- λ、应用的意思两边相同；
- 所以整个定义的意思相同。
————————————————————————————————————————————————-
下面用 `lt` 这个例子，把 Prod、Lambda、App 从 Rocq 源码一路走到 Lean 结果。例子里的数据都来自项目的实际记录（`results/casestudy/declarations/Corelib.Init.Peano.lt.json`），不是手写示意。
## 例子：`lt` 是什么

```coq
Definition lt (n m : nat) := S n <= m.
```

它定义了"小于"：`n < m` 的意思就是 `n + 1 ≤ m`。

这一行里用到了：
- `S`：nat 的构造子，`S n` 就是 n + 1；
- `<=`：`le` 的简写。`le` 在 Rocq 里是一个归纳类型，`le a b` 是一个命题，表示 a ≤ b。

---
## 第一步：Rocq 把它变成两棵树
Rocq 先把这一行补全，得到"类型"和"值"两部分：

```text
类型：forall (n : nat) (m : nat), Prop      也就是 nat → nat → Prop
值：  fun (n : nat) (m : nat) => le (S n) m
```

- **类型**说明 lt 是什么样的东西：输入两个 nat，输出一个命题。
- **值**说明 lt 具体是什么：拿到 n 和 m，返回命题 `le (S n) m`。

在 Rocq 内核里，这两部分各是一棵树：

```text
类型树                          值树
Prod n : nat                    Lambda n : nat
└─ Prod m : nat                 └─ Lambda m : nat
   └─ Prop                         └─ App
                                      ├─ 函数：le
                                      └─ 参数：
                                         ├─ App
                                         │  ├─ 函数：S
                                         │  └─ 参数：n
                                         └─ m
```

可以看到：
- **类型树全是 Prod**：两层 Prod 分别对应"输入 n"和"输入 m"；
- **值树外层是 Lambda，里面是 App**：两层 Lambda 接收 n 和 m，App 负责"把 le 用在 S n 和 m 上"。
### 变量怎么记
树里的 n 和 m 不是按名字记录的，而是按"往外数第几层"记录的：

```text
Lambda n          ← 往外第 1 层
└─ Lambda m       ← 往外第 0 层（最近的一层）
   └─ ... n ... m ...
```

站在最里面往外看，m 最近，记作 `0`；n 远一层，记作 `1`。这个编号叫 de Bruijn 编号，Rocq 和 Lean 都这么记。

---
## 第二步：导出成项目的中间格式
导出器把这两棵树原样写成 JSON。去掉细节后是这样：

```text
类型：prod n (ind nat)
        (prod m (ind nat)
          (sort Prop))

值：  lam n (ind nat)
        (lam m (ind nat)
          (app (ind le)
               [ app (construct nat 第1号) [rel 1],
                 rel 0 ]))
```

对照第一步的树：
- `prod` 就是 Prod，`lam` 就是 Lambda，`app` 就是 App；
- `ind nat`、`ind le` 指归纳类型 nat 和 le；
- `construct nat 第1号` 是 nat 的第 1 号构造子，也就是 S（第 0 号是 O）；
- `rel 1` 是 n，`rel 0` 是 m。

注意 `app` 里的参数是**一个列表**：`le` 一次拿到两个参数。

---
## 第三步：逐个节点翻译成 Lean
翻译器从树根往下走，每遇到一个节点就换成 Lean 里对应的节点。
### 类型树

|遇到|做什么|得到|
|---|---|---|
|`prod n (nat) …`|Prod 换成 forallE；变量名 n 照抄；nat 翻译成 Lean 里生成的 nat|`forallE n Rocq...nat …`|
|`prod m (nat) …`|同上|`forallE m Rocq...nat …`|
|`sort Prop`|Prop 换成 Lean 的 `Sort 0`，也就是 Prop|`sort 0`|

### 值树

|遇到|做什么|得到|
|---|---|---|
|`lam n (nat) …`|Lambda 换成 lam；n 照抄；翻译 nat；记下"现在多了一个变量 n"|`lam n Rocq...nat …`|
|`lam m (nat) …`|同上，又多了一个变量 m|`lam m Rocq...nat …`|
|`app (le) [A, B]`|**先翻译两个参数，再翻译函数，最后拼起来**（见下）|两层 `app`|

App 这一步展开说：
1. 翻译第一个参数 `app (S) [rel 1]`。它本身也是一个 App，只有一个参数：
    - `S` 换成 `Rocq.Corelib.Init.Datatypes.nat.S`；
    - `rel 1` 换成 `bvar 1`，也就是 n；
    - 拼起来：`app (nat.S) (bvar 1)`，即 `S n`。
2. 翻译第二个参数 `rel 0`，换成 `bvar 0`，也就是 m。
3. 翻译函数 `le`，换成 `Rocq.Corelib.Init.Peano.le`。
4. **把一次给两个参数，改成连续给两次，每次一个**：

```text
Rocq：  App(le, [S n, m])            一次给两个
Lean：  app (app le (S n)) m         先给 S n，再给 m
```

### 翻译结果
项目记录里的实际输出（名字前缀省略）：

```text
类型：forallE n nat (forallE m nat (sort 0))
值：  lam n nat (lam m nat (app (app le (app S (bvar 1))) (bvar 0)))
```

和 Rocq 那两棵树对照，**形状完全一样**：
- Prod 的位置变成 forallE；
- Lambda 的位置变成 lam；
- App 的位置变成 app，只是多参数拆成了嵌套。

---
## 第四步：Lean 检查翻译结果
翻译出来的东西要交给 Lean 内核检查。Lean 对这三种节点各有一条检查规则，和 Rocq 的规则相同。用 lt 走一遍：
### 检查类型 `forallE n nat (forallE m nat Prop)`
Lean 的 forall 规则：**输入的类型必须是类型，输出也必须是类型。**
- 外层：n 的类型 nat 是类型；里面的 `forallE m nat Prop` 也要是类型 → 继续检查；
- 内层：m 的类型 nat 是类型；输出 Prop 是类型。

所以 `nat → nat → Prop` 是一个合法的类型。
### 检查值 `lam n nat (lam m nat (…))`
Lean 的 lam 规则：**先确认参数类型是类型，然后在"有了这个参数"的前提下看 body 的类型。整个 lam 的类型就是"输入参数类型，输出 body 的类型"。**
- 有了 n : nat 和 m : nat 之后，检查 body `le (S n) m` 的类型（见下面）；
- 如果 body 的类型是 Prop，那么整个值的类型就是 `nat → nat → Prop`。
### 检查 body `app (app le (S n)) m`
Lean 的 app 规则：**f 必须是函数；参数的类型必须正好是 f 要求的类型；结果是 f 的输出类型。**

从里往外：

|检查|f 要求什么|实际给了什么|结果|
|---|---|---|---|
|`S n`|S 要求 nat|n 是 nat |`S n` 是 nat|
|`le (S n)`|le 要求 nat|`S n` 是 nat |得到一个"还要一个 nat、再给出命题"的函数|
|`le (S n) m`|要求 nat|m 是 nat |得到 Prop|

所以 body 的类型是 Prop。往回推，整个值的类型是 `nat → nat → Prop`，**和声明的类型一致**。

这个例子里，每个参数的类型都**正好**等于要求的类型，没有用到 Rocq 的"小一层也行"，所以不需要加 `PULift`。

---
## 第五步：结果
Lean 内核接受了这个定义。打印出来是：

```lean
def Rocq.Corelib.Init.Peano.lt :
    Rocq.Corelib.Init.Datatypes.nat → Rocq.Corelib.Init.Datatypes.nat → Prop :=
  fun n m => Rocq.Corelib.Init.Peano.le n.S m
```

`n.S` 是 Lean 显示 `S n` 的一种写法。项目记录的状态是 `TRANSLATED_AND_CHECKED`（翻译完成，检查通过），没有需要另外证明的条件。

---
## 总结：三个节点各走了什么流程

|节点|在 lt 里出现在哪|翻译时做什么|Lean 检查什么|
|---|---|---|---|
|**Prod → forallE**|类型 `nat → nat → Prop` 的两层|换节点名；变量名照抄；里面的类型逐个翻译|输入是类型，输出也是类型|
|**Lambda → lam**|值 `fun n m => …` 的两层|换节点名；变量名照抄；记下新变量，翻译 body|参数类型是类型；整个 lam 的类型 = "输入参数类型，输出 body 的类型"|
|**App → app**|`le (S n) m` 和 `S n`|先翻参数，再翻函数；多个参数拆成一层层嵌套|f 是函数；参数类型正好等于要求的类型；结果是 f 的输出类型|

整个流程可以概括成三步：
1. **结构不变**：Rocq 的树和 Lean 的树形状一样，三种节点一一换名；
2. **只换叶子**：nat、le、S 换成 Lean 里的名字，变量编号照搬；
3. **检查规则相同**：Lean 用和 Rocq 相同的三条规则检查，所以 Rocq 里成立的定义，翻过来在 Lean 里也成立。